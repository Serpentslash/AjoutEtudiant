/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LesProduits;

/**
 *
 * @author Rabelais
 */
public class Pdtfabatl extends Pdtfab
{
    private String nomAtelier;

    public Pdtfabatl(String reference, String designation, float coutMP, float coutMO, float prixVente, String nomAtelier)
    {
        super(coutMP, coutMO, reference, designation, prixVente);
        this.nomAtelier = nomAtelier;
    }

    public String getNomAtelier()
    {
        return nomAtelier;
    }

    public void setNomAtelier(String nomAtelier)
    {
        this.nomAtelier = nomAtelier;
    }
    
    public void affiche()
    {
        super.affiche();
        System.out.println("Nom de l'atelier: " + nomAtelier);
    }
}
