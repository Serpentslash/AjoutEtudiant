/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionsection;

/**
 *
 * @author Rabelais
 */
public class Section
{
    private String nom;
    private Eleve[] tabEleves;
    private int effectif;

    public Section()
    {
    }

    public Section(String nom, Eleve[] tabEleves, int effectif)
    {
        this.nom = nom;
        this.tabEleves = tabEleves;
        this.effectif = effectif;
    }

    public Section(int num)
    {
        this.nom = "TSSIO" + num;
        tabEleves = new Eleve[30];
        this.effectif = 0;
    }
    
    public void affichnomsec()
    {
        System.out.println("Section: " + nom);
    }
    
    public void ajouter(Eleve e)
    {
        tabEleves[effectif] = e;
        effectif++;
    }
    
    public Eleve meilleur()
    {
        Eleve leMeilleur = tabEleves[0];
        for(int i=1; i < effectif; i++)
        {
            if(leMeilleur.moyenne() < tabEleves[i].moyenne())
            {
                leMeilleur = tabEleves[i];
            }
        }
        return leMeilleur;
    }
    
    public float moygen()
    {
        float total = 0;
        for(int i=0; i < effectif; i++)
        {
            total += tabEleves[i].moyenne();
        }
        return total / effectif;
    }
    
    public Section compare(Section s)
    {
        Section laMeilleur;
        if(s.moygen() > moygen())
        {
            laMeilleur = s;
        }
        else
        {
            laMeilleur = this;
        }
        return laMeilleur;
    }
    
    public void affichelevsec()
    {
        for(int i=0; i < effectif; i++)
        {
            System.out.println(tabEleves[i].getNom() + " avec une moyenne de :" + tabEleves[i].moyenne());
        }
    }
    
    public void affichelevsec(float moyMin)
    {
        for(int i=0; i < effectif; i++)
        {
            if(tabEleves[i].moyenne() >= moyMin)
            {
                System.out.println(tabEleves[i].getNom() + " avec une moyenne de :" + tabEleves[i].moyenne());
            }
        }
    }
    
    public String getNom()
    {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }
    
}
