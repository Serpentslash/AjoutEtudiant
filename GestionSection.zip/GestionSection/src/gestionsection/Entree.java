package gestionsection;
import java.io.*;
// Classe Entree permettant la saisie et la conversion de donn�es saisies au clavier.
     

public class Entree 
{
	static BufferedReader rep = new BufferedReader(new InputStreamReader(System.in));
        
        /** Méthode permettant de saisir un nombre à virgule **/
	public static float flottant(String msg) throws IOException  
	{
		System.out.println(msg);
		try 
		{
			
			float valeur = Float.parseFloat(rep.readLine());
			return valeur;
		}
		catch (NumberFormatException e)
		{
			return Entree.flottant ("Zone absente ou type incorrect, essayez a nouveau");
			
		}	
		
	}
        
        /** Méthode permettant de saisir un nombre entier **/
	public static int entier(String msg) throws IOException  
	{
		System.out.println(msg);
		try 
		{
			
			int valeur = Integer.parseInt(rep.readLine());
			return valeur;
		}
		catch (NumberFormatException e)
		{
			return Entree.entier ("Zone absente ou type incorrect, essayez a nouveau");
			
		}
	}
        
        /** Méthode permettant de saisir des caractères **/
	public static char caractere(String msg) throws IOException  
	{
		System.out.println(msg);
		try 
		{
			char valeur = rep.readLine().charAt(0);;
			return valeur;
		}
		catch (StringIndexOutOfBoundsException e)
		{
			return Entree.caractere ("Zone absente, essayez a nouveau");
		}
	}

        /** Méthode permettant de saisir un double **/
	public static double reeldouble (String msg)  throws IOException
	{
		System.out.println(msg);
		try 
		{
			double valeur = Double.parseDouble(rep.readLine());
			return valeur;
		}
		catch (NumberFormatException e)
		{
			return Entree.reeldouble ("Zone absente ou type incorrect, essayez a nouveau");
			
		}		
	}		
	
        /** Méthode permettant de saisir une chaine **/
	public static String chaine(String msg) throws IOException
 	{
		System.out.println(msg);
		String valeur = rep.readLine();
		return valeur;
	}
}
