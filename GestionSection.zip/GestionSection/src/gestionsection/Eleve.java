/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestionsection;

/**
 *
 * @author Rabelais
 */
public class Eleve
{
    private String nom;
    private float noteE, noteO;

    public Eleve()
    {
    }

    public Eleve(String nom, float noteE, float noteO)
    {
        this.nom = nom;
        this.noteE = noteE;
        this.noteO = noteO;
    }

    public String getNom()
    {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public float getNoteE()
    {
        return noteE;
    }

    public void setNoteE(float noteE)
    {
        this.noteE = noteE;
    }

    public float getNoteO()
    {
        return noteO;
    }

    public void setNoteO(float noteO)
    {
        this.noteO = noteO;
    }
    
    public float moyenne()
    {
        return (noteE + noteO) / 2;
    }
    
    public void affiche()
    {
        System.out.println(nom + " a une moyenne de " + moyenne());
    }
}
