/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LesProduits;

/**
 *
 * @author Rabelais
 */
public class Pdtfabusi extends Pdtfab
{
    private String nomUsine;

    public Pdtfabusi(String reference, String designation, float coutMP, float coutMO, float prixVente, String nomUsine)
    {
        super(coutMP, coutMO, reference, designation, prixVente);
        this.nomUsine = nomUsine;
    }

    public String getNomUsine()
    {
        return nomUsine;
    }

    public void setNomUsine(String nomUsine)
    {
        this.nomUsine = nomUsine;
    }
    
    public void affiche()
    {
        super.affiche();
        System.out.println("Nom de l'usine: " + nomUsine);
    }
}
