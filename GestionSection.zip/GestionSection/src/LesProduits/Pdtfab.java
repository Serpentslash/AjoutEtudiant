/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LesProduits;

/**
 *
 * @author Rabelais
 */
public class Pdtfab extends Produit
{
    private float coutMP;
    private float coutMO;

    public Pdtfab(float coutMP, float coutMO, String reference, String designation, float prixVente)
    {
        super(reference, designation, prixVente);
        this.coutMP = coutMP;
        this.coutMO = coutMO;
    }

    public float getCoutMP()
    {
        return coutMP;
    }

    public void setCoutMP(float coutMP)
    {
        this.coutMP = coutMP;
    }

    public float getCoutMO()
    {
        return coutMO;
    }

    public void setCoutMO(float coutMO)
    {
        this.coutMO = coutMO;
    }
    
    public void affiche()
    {
        super.affiche();
        System.out.println("Cout matieres premieres: " + coutMP + "\n Cout main d'oeuvre: " + coutMO);
    }
}
