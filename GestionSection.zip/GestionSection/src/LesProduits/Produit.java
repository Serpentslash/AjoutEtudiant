/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LesProduits;

/**
 *
 * @author Rabelais
 */
public class Produit
{
    private String reference;
    private String designation;
    private float prixVente;

    public Produit(String reference, String designation, float prixVente)
    {
        this.reference = reference;
        this.designation = designation;
        this.prixVente = prixVente;
    }

    public String getReference()
    {
        return reference;
    }

    public void setReference(String reference)
    {
        this.reference = reference;
    }

    public String getDesignation()
    {
        return designation;
    }

    public void setDesignation(String designation)
    {
        this.designation = designation;
    }

    public float getPrixVente()
    {
        return prixVente;
    }

    public void setPrixVente(float prixVente)
    {
        this.prixVente = prixVente;
    }
    
    public void affiche()
    {
        System.out.println("Reference: " + reference + "\nDesignation: " + designation + "\nPrix de vente: " + prixVente);
    }
}
