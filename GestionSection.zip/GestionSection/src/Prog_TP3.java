import gestionsection.Eleve;
import gestionsection.Entree;
import gestionsection.Section;
import java.io.*;
class Prog_TP3
{
	public static void main(String argv[]) throws IOException
	{
		int sec, sec2, i, j, choix, op, nbsec=2;
		float moy;
		String sai;
		Section[] tab = new Section[nbsec];
		boolean tabExiste[] = new boolean[nbsec];
		for (i=0; i<nbsec ; i++)
			tabExiste[i] = false;

		do
		{
			System.out.println("\nMenu general (la plupart des controles de saisie n'ont pas ?t? effectu?s)");
			System.out.println("\n************");
			System.out.println("\n1 : Ajout d'une section");
			System.out.println("\n2 : Afficher tous les ?l?ves");
			System.out.println("\n3 : Afficher les ?l?ves d'une section");
			System.out.println("\n4 : Afficher les ?l?ves d'une section ayant une moyenne <= ou >= a la valeur saisie");			
			System.out.println("\n5 : Afficher le meilleur ?l?ve d'une section");
			System.out.println("\n6 : Afficher la meilleure section");
			System.out.println("\n7 : Quitter");
			choix=Entree.entier("\n\n\nSaisir votre choix");
			switch(choix)
			{
				case 1 :
                                
					do
						sec = Entree.entier("\nSaisir le numero de la section");
					while (sec <= 0 || sec > nbsec);
					if (tabExiste[sec-1])
						System.out.println("\nCette section existe deja");
					else
					{
						tab[sec-1] = new Section(sec);
                                                // Ajouter des eleves
                                                int nb = Entree.entier("Combien d'eleves voulez-vous creer ? ");
                                                String nom="";
                                                for (i=0; i < nb; i++)
                                                {
                                                    nom = Entree.chaine("Saisir le nom de l'eleve " + i);
                                                    float noteEcrit = Entree.flottant("Note d'ecrit ? ");
                                                    float noteOral = Entree.flottant("Note d'oral ? ");
                                                    Eleve e = new Eleve(nom, noteEcrit, noteOral);
                                                    tab[sec-1].ajouter(e);
                                                }
                                                tabExiste[sec-1]=true;
					}
				 	break;
				 
				case 2 : 
					for (i = 0; i<nbsec; i++)
					{
						if (tabExiste[i])
						{
							System.out.println("\n-- El?ves de la section tsig" + (i+1) + " --");
							tab[i].affichelevsec();
						}	
					}
					break;
				 
				case 3 : 
					// on n'effectue pas le ctrl de saisie
					sec = Entree.entier("\nSaisir le num?ro de la section");
					System.out.println("\n-- El?ves de la section tsig" + sec + " --");
					tab[sec-1].affichelevsec();
					break;
			
				case 4 :
					 // on n'effectue pas le ctrl de saisie
					 sec = Entree.entier("\nSaisir le num?ro de la section");
					 moy = Entree.flottant("Saisir la moyenne");
				 
					 do
					 {
				 		op = Entree.entier("Saisir 1 pour afficher les ?l?ves qui ont une moyenne <= ? la valeur saisie ou 2 pour >=");					 }
					 while(op != 1 && op != 2);
				
					 tab[sec-1].affichelevsec(moy);
					 break;
				 
				case 5 : 
					 // on n'effectue pas le ctrl de saisie
					 sec = Entree.entier("\nSaisir le num?ro de la section");
					 tab[sec-1].meilleur().affiche();
					 
					 break;
				 
				case 6 : 
					 // on n'effectue pas le ctrl de saisie
					 sec = Entree.entier("\nSaisir le num?ro de la section");
					 sec2 = Entree.entier("Saisir le num?ro d'une autre section");
				 
					 System.out.println("Meilleure des 2 sections :");
					 tab[sec-1].compare(tab[sec2-1]).affichnomsec();
					 break;
					 
				case 7 : System.out.println("Au revoir");
					 break;
			
			}
			// Saisie factice afin de permettre ? l'utilisateur de vopir le r?sultat affich?
			if (choix != 1)
				sai=Entree.chaine("\nAppuyer sur une touche pour revenir au menu");
		}
		while (choix!=7);
	}
}