/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package LesProduits;

/**
 *
 * @author Rabelais
 */
public class Pdtach extends Produit
{
    private String nomFournisseur;
    private float prixAchat;

    public Pdtach(String reference, String designation,  float prixVente, String nomFournisseur, float prixAchat)
    {
        super(reference, designation, prixVente);
        this.nomFournisseur = nomFournisseur;
        this.prixAchat = prixAchat;
    }

    public String getNomFournisseur()
    {
        return nomFournisseur;
    }

    public void setNomFournisseur(String nomFournisseur)
    {
        this.nomFournisseur = nomFournisseur;
    }

    public float getPrixAchat()
    {
        return prixAchat;
    }

    public void setPrixAchat(float prixAchat)
    {
        this.prixAchat = prixAchat;
    }
    
    public void affiche()
    {
        super.affiche();
        System.out.println("Nom du fournisseur: " + nomFournisseur + "Prix d'achat" + prixAchat);
    }
}
